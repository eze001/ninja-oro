export default{
    state:{
        oro:0,
        actividades:[],
        i:0,
    },
    incrementaroro(tipolugar){
        var a=Math.random();
        var b=Math.random();
        var c=0;
        var i=this.state.i;
        if(b>=0.5){
            if(tipolugar=="Granja"){
                c=10+Math.trunc(11*a);
                this.state.oro+=c;
                console.log('granja +');
                this.state.actividades[i]="Ganaste "+c+ " de oro de la granja";
            }
            if(tipolugar=="Cueva"){
                c=5+Math.trunc(6*a);
                this.state.oro+=c;
                console.log('cueva +');
                this.state.actividades[i]="Ganaste "+c+ " de oro de la cueva";
            }
            if(tipolugar=="Casa"){
                c=2+Math.trunc(4*a);
                this.state.oro+=c;
                console.log('casa +');
                this.state.actividades[i]="Ganaste "+c+ " de oro de la casa";
            }
            if(tipolugar=="Casino"){
                c=Math.trunc(51*a);
                this.state.oro+=c;
                console.log('casino +');
                this.state.actividades[i]="Ganaste "+c+ " de oro del casino";
            }
        }else{
            if(tipolugar=="Granja"){
                c=10+Math.trunc(11*a);
                this.state.oro-=c;
                console.log('granja -');
                this.state.actividades[i]="Perdiste "+c+ " de oro de la granja";
            }
            if(tipolugar=="Cueva"){
                c=5+Math.trunc(6*a);
                this.state.oro-=c;
                console.log('cueva -');
                this.state.actividades[i]="Perdiste "+c+ " de oro de la cueva";
            }
            if(tipolugar=="Casa"){
                c=2+Math.trunc(4*a);
                this.state.oro-=c;
                console.log('casa -');
                this.state.actividades[i]="Perdiste "+c+ " de oro de la casa";
            }
            if(tipolugar=="Casino"){
                c=Math.trunc(51*a);
                this.state.oro-=c;
                console.log('casino -');
                this.state.actividades[i]="Perdiste "+c+ " de oro del casino";
            }    
        }
        this.state.i++;
    },
}